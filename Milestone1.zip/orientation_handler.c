#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_i2c.h"
#include "driverlib/pin_map.h" //Needed for pin configure
#include "driverlib/systick.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/i2c.h"
#include "utils/ustdlib.h"
#include "acc.h"
#include "i2c_driver.h"

#include <math.h>

#include "orientation_handler.h"

#define CIRC_BUFFER_SIZE 10

#define INSTABILITY_FRACTION 0.01


static int16_t acclXBuffer[CIRC_BUFFER_SIZE] = {0};
static int16_t acclYBuffer[CIRC_BUFFER_SIZE] = {0};
static int16_t acclZBuffer[CIRC_BUFFER_SIZE] = {0};
static uint8_t circBufferIdx = 0;

static int16_t intSign(int16_t value);

/*********************************************************
 * initAccl
 *********************************************************/
void initAccl (void)
{
    char    toAccl[] = {0, 0};  // parameter, value

    /*
     * Enable I2C Peripheral
     */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C0);

    /*
     * Set I2C GPIO pins
     */
    GPIOPinTypeI2C(I2CSDAPort, I2CSDA_PIN);
    GPIOPinTypeI2CSCL(I2CSCLPort, I2CSCL_PIN);
    GPIOPinConfigure(I2CSCL);
    GPIOPinConfigure(I2CSDA);

    /*
     * Setup I2C
     */
    I2CMasterInitExpClk(I2C0_BASE, SysCtlClockGet(), true);

    GPIOPinTypeGPIOInput(ACCL_INT2Port, ACCL_INT2);

    //Initialize ADXL345 Acceleromter

    // set +-2g, 13 bit resolution, active low interrupts
    toAccl[0] = ACCL_DATA_FORMAT;
    toAccl[1] = (ACCL_RANGE_2G | ACCL_FULL_RES);
    I2CGenTransmit(toAccl, 1, WRITE, ACCL_ADDR);

    toAccl[0] = ACCL_PWR_CTL;
    toAccl[1] = ACCL_MEASURE;
    I2CGenTransmit(toAccl, 1, WRITE, ACCL_ADDR);


    toAccl[0] = ACCL_BW_RATE;
    toAccl[1] = ACCL_RATE_100HZ;
    I2CGenTransmit(toAccl, 1, WRITE, ACCL_ADDR);

    toAccl[0] = ACCL_INT;
    toAccl[1] = 0x00;       // Disable interrupts from accelerometer.
    I2CGenTransmit(toAccl, 1, WRITE, ACCL_ADDR);

    toAccl[0] = ACCL_OFFSET_X;
    toAccl[1] = 0x00;
    I2CGenTransmit(toAccl, 1, WRITE, ACCL_ADDR);

    toAccl[0] = ACCL_OFFSET_Y;
    toAccl[1] = 0x00;
    I2CGenTransmit(toAccl, 1, WRITE, ACCL_ADDR);

    toAccl[0] = ACCL_OFFSET_Z;
    toAccl[1] = 0x00;
    I2CGenTransmit(toAccl, 1, WRITE, ACCL_ADDR);
}




/********************************************************
 * Function to read accelerometer
 ********************************************************/
vector3_t
getAcclData (void)
{
    char    fromAccl[] = {0, 0, 0, 0, 0, 0, 0}; // starting address, placeholders for data to be read.
    vector3_t acceleration;
    uint8_t bytesToRead = 6;

    fromAccl[0] = ACCL_DATA_X0;
    I2CGenTransmit(fromAccl, bytesToRead, READ, ACCL_ADDR);

    acceleration.x = (fromAccl[2] << 8) | fromAccl[1]; // Return 16-bit acceleration readings.
    acceleration.y = (fromAccl[4] << 8) | fromAccl[3];
    acceleration.z = (fromAccl[6] << 8) | fromAccl[5];

    return acceleration;
}



void updateAccl(void)
{
    vector3_t accel = getAcclData();

    acclXBuffer[circBufferIdx] = accel.x;
    acclYBuffer[circBufferIdx] = accel.y;
    acclZBuffer[circBufferIdx] = accel.z;
    circBufferIdx = (circBufferIdx + 1) % CIRC_BUFFER_SIZE;
}



vector3_t getAcclAvg(void)
{
//    return getAcclData();

    vector3_t accel = {0};
    uint8_t i;
    for (i = 0; i < CIRC_BUFFER_SIZE; i++) {
        accel.x += acclXBuffer[i];
        accel.y += acclYBuffer[i];
        accel.z += acclZBuffer[i];
    }

    accel.x /= CIRC_BUFFER_SIZE;
    accel.y /= CIRC_BUFFER_SIZE;
    accel.z /= CIRC_BUFFER_SIZE;

    return accel;
}



rotation_t getAcclAngles(void)
{
    // From the NXP doc on LEARN, page 13 (Eqns. 37 and 38)
    vector3_t accel = getAcclAvg();
    rotation_t rotation;

//    rotation.theta = 1.234;
//    rotation.phi = -4.567;

    rotation.pitch = (float) -atan2(-accel.x, sqrt(pow(accel.y, 2) + pow(accel.z, 2)));
    rotation.roll =   (float) -atan2( accel.y, intSign(accel.z) * sqrt(INSTABILITY_FRACTION * pow(accel.x, 2) + pow(accel.z, 2)));

//    rotation.phi =   (float) atan2( accel.y, sqrt(INSTABILITY_FRACTION * pow(accel.x, 2) + pow(accel.z, 2))));

    return rotation;
}


static int16_t intSign(int16_t value)
{
    if (value < 0) {
        return -1;
    } else {
        return 1;
    }
}
