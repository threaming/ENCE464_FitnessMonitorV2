#ifndef ORIENTATION_HANDLER_H
#define ORIENTATION_HANDLER_H

typedef struct {
    int16_t x;
    int16_t y;
    int16_t z;
} vector3_t;

typedef struct {
    float pitch; // -pitch (used to be theta)
    float roll; // -1 * roll (used to be phi)
} rotation_t;

void initAccl (void);
void updateAccl(void);
vector3_t getAcclAvg(void);
rotation_t getAcclAngles(void);


#endif // ORIENTATION_HANDLER_H
