/**********************************************************
 *
 * milestone_1.c
 * Matt Suter 2022
 * ENCE361 S1 2022
 *
 **********************************************************/

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_i2c.h"
#include "driverlib/pin_map.h" //Needed for pin configure
#include "driverlib/systick.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/i2c.h"
#include "../OrbitOLED/OrbitOLEDInterface.h"
#include "utils/ustdlib.h"
#include "acc.h"
#include "i2c_driver.h"
#include "buttons4.h"

#include "orientation_handler.h"


/**********************************************************
 * Constants
 **********************************************************/
// Systick configuration
#define SYSTICK_RATE_HZ    10

#define GRAV_CONSTANT 9810
#define ONE_G_READING 255
#define LOOP_REFRESH_RATE 60
#define DISPLAY_REFRESH_RATE 5
#define ANGLE_DISPLAY_TIME 3

typedef enum {
    DISPLAY_RAW = 0,
    DISPLAY_G,
    DISPLAY_SI,
    DISPLAY_NUM_MODES, // Extra 'state', that tells us the number of display modes that exist
} DisplayUnits_t;

/*******************************************
 *      Local prototypes
 *******************************************/
void initClock (void);
void initDisplay (void);
void displayUpdate (char *prefix, char *suffix, int16_t num, uint8_t charLine, bool thousandsFormatting);
void initAccl (void);
vector3_t getAcclData (void);
static void displayAccel(vector3_t toDisplay, DisplayUnits_t mode);

static DisplayUnits_t currentDisplayUnits = DISPLAY_RAW;

/***********************************************************
 * Initialisation functions: clock, SysTick, PWM
 ***********************************************************
 * Clock
 ***********************************************************/
void
initClock (void)
{
    // Set the clock rate to 20 MHz
    SysCtlClockSet (SYSCTL_SYSDIV_10 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN |
                   SYSCTL_XTAL_16MHZ);
}

/*********************************************************
 * initDisplay
 *********************************************************/
void
initDisplay (void)
{
    // Initialise the Orbit OLED display
    OLEDInitialise ();
}

//*****************************************************************************
// Function to display a changing message on the display.
// The display has 4 rows of 16 characters, with 0, 0 at top left.
//*****************************************************************************
void
displayUpdate (char *prefix, char *suffix, int16_t num, uint8_t charLine, bool thousandsFormatting)
{
    char text_buffer[17];           //Display fits 16 characters wide.

    // "Undraw" the previous contents of the line to be updated.
    OLEDStringDraw ("                ", 0, charLine);


    // Form a new string for the line.  The maximum width specified for the
    //  number field ensures it is displayed right justified.

    // Print the value, as a 3dp fraction
//    int16_t new_num = num * GRAV_CONSTANT / ONE_G_READING;
//    usnprintf(text_buffer, sizeof(text_buffer), "%s %s %c%d.%03d ms-2", str1, str2, new_num<0? '-':' ', abs(new_num / 1000), abs(new_num) % 1000);

    // Print the angle
    if (thousandsFormatting) {
        // Print a number/1000 to 3dp, with decimal point and sign
        usnprintf(text_buffer, sizeof(text_buffer), "%s %c%d.%03d %s", prefix, num<0? '-':' ', abs(num / 1000), abs(num) % 1000, suffix);
    } else {
        usnprintf(text_buffer, sizeof(text_buffer), "%s %4d %s", prefix, num, suffix);
    }

    // Update line on display.
    OLEDStringDraw (text_buffer, 0, charLine);
}






/********************************************************
 * main
 ********************************************************/
int
main (void)
{
    vector3_t accelerationReading;
    rotation_t deviceRotation;
    uint16_t angleDisplayTimer = 0;
    currentDisplayUnits = DISPLAY_RAW; // Init to showing the current angle
    deviceRotation = getAcclAngles();
    bool displayingAngles = true;
    uint16_t displayUpdateCounter = 0;

    initClock ();
    initAccl ();
    initDisplay ();
    initButtons();

    // OLEDStringDraw ("Accelerometer", 0, 0);

    while (1)
    {
        SysCtlDelay (SysCtlClockGet () / (LOOP_REFRESH_RATE*3));    // Approx X/3 Hz
        updateAccl();
        updateButtons();
        accelerationReading = getAcclAvg();
        angleDisplayTimer++;

        displayUpdateCounter = (displayUpdateCounter + 1) % (LOOP_REFRESH_RATE/DISPLAY_REFRESH_RATE);

        // Display the measured angle for 3 seconds
        if (checkButton(DOWN) == PUSHED && !displayingAngles) {
            displayingAngles = true;
            angleDisplayTimer = 0;
            deviceRotation = getAcclAngles(); // Lock in the reference rotation here, instead of constantly updating it over the 3s window
        }

        // After the timer elapses, go back to showing raw acceleration
        if (displayingAngles && angleDisplayTimer > ANGLE_DISPLAY_TIME * LOOP_REFRESH_RATE) {
            displayingAngles = false;
        }

        // Display the current acceleration, in customizable units
        if (checkButton(UP) == PUSHED && !displayingAngles) {
            // Increment the current display mode
            currentDisplayUnits = (currentDisplayUnits + 1) % DISPLAY_NUM_MODES;
        }

        // Update the display less frequently, to improve performance
        if (displayUpdateCounter == 0) {
            if (displayingAngles) {
//                deviceRotation = getAcclAngles(); // Uncomment this to get a constant readout
                OLEDStringDraw ("Angle Reading   ", 0, 0);
                displayUpdate ("PITCH", "rad", (uint16_t)(deviceRotation.pitch * 1000), 1, true);
                displayUpdate ("ROLL ", "rad", (uint16_t)(deviceRotation.roll  * 1000), 2, true);
                displayUpdate ("                    ", "", 0, 3, false); // display an empty line
            } else {
                displayAccel(accelerationReading, currentDisplayUnits);
            }
        }

    }
}


// Display an acceleration on the screen, converting to the desired units
static void displayAccel(vector3_t toDisplay, DisplayUnits_t mode)
{
//    OLEDStringDraw ("                ", 0, charLine);
    switch (mode) {
        case DISPLAY_RAW:
            OLEDStringDraw ("Raw Values      ", 0, 0);
            displayUpdate ("X", "units", toDisplay.x, 1, false);
            displayUpdate ("Y", "units", toDisplay.y, 2, false);
            displayUpdate ("Z", "units", toDisplay.z, 3, false);
            break;

        case DISPLAY_G:
            OLEDStringDraw ("In terms of G   ", 0, 0);
            displayUpdate ("X", "g", (1000 * toDisplay.x) / ONE_G_READING, 1, true);
            displayUpdate ("Y", "g", (1000 * toDisplay.y) / ONE_G_READING, 2, true);
            displayUpdate ("Z", "g", (1000 * toDisplay.z) / ONE_G_READING, 3, true);
            break;

        case DISPLAY_SI:
            OLEDStringDraw ("SI units        ", 0, 0);
            displayUpdate ("X", "ms-2", (GRAV_CONSTANT * toDisplay.x) / ONE_G_READING, 1, true);
            displayUpdate ("Y", "ms-2", (GRAV_CONSTANT * toDisplay.y) / ONE_G_READING, 2, true);
            displayUpdate ("Z", "ms-2", (GRAV_CONSTANT * toDisplay.z) / ONE_G_READING, 3, true);
            break;
    }
}

